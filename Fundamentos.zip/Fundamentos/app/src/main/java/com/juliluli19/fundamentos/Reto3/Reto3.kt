package com.juliluli19.fundamentos.Reto3

class Reto3 {

}

class Articulo(val nombre: String, val precioBase: Double) {
    var precioActual: Double = precioBase
        private set

    fun hacerOferta(oferta: Double) {
        if (oferta > precioActual) {
            precioActual = oferta
            println("Oferta aceptada: $oferta")
        } else {
            println("La oferta debe ser mayor al precio actual.")
        }
    }

    fun vender() {
        if (precioActual > precioBase) {
            println("El artículo $nombre se vendió por $precioActual")
        } else {
            println("El artículo $nombre no recibió ofertas y se vendió a la casa de subastas por el precio base de $precioBase")
        }
    }
}

class Subasta {
    private val articulos = mutableListOf<Articulo>()

    fun agregarArticulo(articulo: Articulo) {
        articulos.add(articulo)
    }

    fun recibirOfertas() {
        for (articulo in articulos) {
            println("Subasta para el artículo: ${articulo.nombre}")
            println("Precio base: ${articulo.precioBase}")

            while (true) {
                println("Ingrese una oferta para el artículo (o 0 para no ofertar):")
                val oferta = readLine()?.toDoubleOrNull() ?: 0.0

                if (oferta == 0.0) {
                    break
                }

                articulo.hacerOferta(oferta)
            }

            articulo.vender()
            println()
        }
    }
}

fun main() {
    val subasta = Subasta()

    val articulo1 = Articulo("Cuadro", 100.0)
    val articulo2 = Articulo("Reloj", 200.0)
    val articulo3 = Articulo("Escultura", 150.0)

    subasta.agregarArticulo(articulo1)
    subasta.agregarArticulo(articulo2)
    subasta.agregarArticulo(articulo3)

    subasta.recibirOfertas()
}
