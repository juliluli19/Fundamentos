package com.juliluli19.fundamentos.reto5

class Nequi {
    private val usuario = "1234567890"
    private val clave = "1234"
    private var saldoDisponible = 4500.0
    private var intentos = 3

    fun iniciarSesion() {
        println("Bienvenido a Nequi Colombia")
        println("Ingresa tu número de celular:")
        val numeroCelular = readLine() ?: ""
        println("Ingresa tu clave de 4 dígitos:")
        val claveIngresada = readLine() ?: ""

        if (numeroCelular == usuario && claveIngresada == clave) {
            println("Acceso permitido.")
            mostrarSaldo()
            menuPrincipal()
        } else {
            intentos--
            if (intentos > 0) {
                println("¡Upps! Parece que tus datos de acceso no son correctos. Tienes $intentos intentos más.")
                iniciarSesion()
            } else {
                println("¡Upps! Has excedido el número de intentos permitidos. Hasta luego.")
            }
        }
    }

    fun mostrarSaldo() {
        println("Saldo disponible: $saldoDisponible")
    }

    fun sacar() {
        println("Escoge una opción:")
        println("1. Cajero")
        println("2. Punto físico")
        val opcion = readLine()?.toIntOrNull() ?: return

        if (saldoDisponible < 2000) {
            println("No te alcanza para realizar el retiro.")
            return
        }

        when (opcion) {
            1 -> {
                println("Confirmar retiro en cajero.")
                println("Ingrese la cantidad que desea retirar:")
                val cantidad = readLine()?.toDoubleOrNull() ?: return

                if (cantidad > saldoDisponible) {
                    println("No tienes suficiente saldo para retirar esa cantidad.")
                } else {
                    saldoDisponible -= cantidad
                    println("Retiro exitoso. Saldo disponible: $saldoDisponible")
                }
            }
            2 -> {
                println("Confirmar retiro en punto físico.")
                println("Ingrese la cantidad que desea retirar:")
                val cantidad = readLine()?.toDoubleOrNull() ?: return

                if (cantidad > saldoDisponible) {
                    println("No tienes suficiente saldo para retirar esa cantidad.")
                } else {
                    saldoDisponible -= cantidad
                    println("Retiro exitoso. Saldo disponible: $saldoDisponible")
                }
            }
            else -> println("Opción inválida.")
        }
    }

    fun enviar() {
        println("Ingrese el número de teléfono al que desea enviar dinero:")
        val numeroDestino = readLine() ?: ""
        println("Ingrese el valor a enviar:")
        val valor = readLine()?.toDoubleOrNull() ?: return

        if (valor > saldoDisponible) {
            println("No es posible enviar el dinero. No tienes suficiente saldo.")
        } else {
            saldoDisponible -= valor
            println("Dinero enviado exitosamente. Saldo disponible: $saldoDisponible")
        }
    }

    fun recargar() {
        println("Ingrese el valor a recargar:")
        val valorRecarga = readLine()?.toDoubleOrNull() ?: return

        println("¿Deseas confirmar la recarga de $valorRecarga? (Sí/No)")
        val confirmacion = readLine() ?: ""

        if (confirmacion.equals("Sí", ignoreCase = true)) {
            saldoDisponible += valorRecarga
            println("Recarga exitosa. Saldo disponible: $saldoDisponible")
        } else {
            println("Recarga cancelada.")
        }
    }

    fun menuPrincipal() {
        while (true) {
            println("\nMenú Principal:")
            println("1. Sacar")
            println("2. Enviar")
            println("3. Recargar")
            println("4. Salir")
            print("Seleccione una opción: ")

            val opcion = readLine()?.toIntOrNull() ?: continue

            when (opcion) {
                1 -> sacar()
                2 -> enviar()
                3 -> recargar()
                4 -> {
                    println("Saliendo de Nequi Colombia. Hasta luego.")
                    break
                }
                else -> println("Opción inválida.")
            }

            mostrarSaldo()
        }
    }
}

fun main() {
    val nequi = Nequi()
    nequi.iniciarSesion()
}

