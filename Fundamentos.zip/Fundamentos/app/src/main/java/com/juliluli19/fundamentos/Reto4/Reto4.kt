package com.juliluli19.fundamentos.Reto4

class Plato(val nombre: String, var descripcion: String, var precio: Double) {
    fun mostrarDetalles() {
        println("Nombre: $nombre")
        println("Descripción: $descripcion")
        println("Precio: $precio")
    }
}

class MenuRestaurante {
    private val entradas = mutableListOf<Plato>()
    private val platosFuertes = mutableListOf<Plato>()
    private val postres = mutableListOf<Plato>()
    private val bebidas = mutableListOf<Plato>()

    fun agregarPlato(categoria: String, plato: Plato) {
        when (categoria) {
            "Entradas" -> entradas.add(plato)
            "Platos Fuertes" -> platosFuertes.add(plato)
            "Postres" -> postres.add(plato)
            "Bebidas" -> bebidas.add(plato)
            else -> println("Categoría inválida")
        }
    }

    fun cantidadPlatos(categoria: String): Int {
        return when (categoria) {
            "Entradas" -> entradas.size
            "Platos Fuertes" -> platosFuertes.size
            "Postres" -> postres.size
            "Bebidas" -> bebidas.size
            else -> 0
        }
    }

    fun mostrarMenu(categoria: String) {
        when (categoria) {
            "Entradas" -> entradas.forEachIndexed { index, plato ->
                println("[$index] ${plato.nombre}")
            }
            "Platos Fuertes" -> platosFuertes.forEachIndexed { index, plato ->
                println("[$index] ${plato.nombre}")
            }
            "Postres" -> postres.forEachIndexed { index, plato ->
                println("[$index] ${plato.nombre}")
            }
            "Bebidas" -> bebidas.forEachIndexed { index, plato ->
                println("[$index] ${plato.nombre}")
            }
            else -> println("Categoría inválida")
        }
    }

    fun modificarPlato(categoria: String, indice: Int, plato: Plato) {
        when (categoria) {
            "Entradas" -> entradas[indice] = plato
            "Platos Fuertes" -> platosFuertes[indice] = plato
            "Postres" -> postres[indice] = plato
            "Bebidas" -> bebidas[indice] = plato
            else -> println("Categoría inválida")
        }
    }

    fun eliminarPlato(categoria: String, indice: Int) {
        when (categoria) {
            "Entradas" -> entradas.removeAt(indice)
            "Platos Fuertes" -> platosFuertes.removeAt(indice)
            "Postres" -> postres.removeAt(indice)
            "Bebidas" -> bebidas.removeAt(indice)
            else -> println("Categoría inválida")
        }
    }
}

fun main() {
    val menu = MenuRestaurante()

    while (true) {
        println("\nMenú del Restaurante")
        println("1. Agregar plato")
        println("2. Mostrar menú")
        println("3. Modificar plato")
        println("4. Eliminar plato")
        println("5. Salir")
        print("Seleccione una opción: ")

        val opcion = readLine()?.toIntOrNull() ?: continue

        when (opcion) {
            1 -> {
                print("Ingrese el nombre del plato: ")
                val nombre = readLine() ?: ""
                print("Ingrese la descripción del plato: ")
                val descripcion = readLine() ?: ""
                print("Ingrese el precio del plato: ")
                val precio = readLine()?.toDoubleOrNull() ?: 0.0

                val plato = Plato(nombre, descripcion, precio)

                println("\nCategorías:")
                println("1. Entradas")
                println("2. Platos Fuertes")
                println("3. Postres")
                println("4. Bebidas")
                print("Seleccione una categoría para agregar el plato: ")

                val categoriaSeleccionada = readLine()?.toIntOrNull() ?: continue

                when (categoriaSeleccionada) {
                    1 -> menu.agregarPlato("Entradas", plato)
                    2 -> menu.agregarPlato("Platos Fuertes", plato)
                    3 -> menu.agregarPlato("Postres", plato)
                    4 -> menu.agregarPlato("Bebidas", plato)
                    else -> println("Opción inválida")
                }
            }
            2 -> {
                println("\nCategorías:")
                println("1. Entradas")
                println("2. Platos Fuertes")
                println("3. Postres")
                println("4. Bebidas")
                print("Seleccione una categoría para mostrar el menú: ")

                val categoriaMostrar = readLine()?.toIntOrNull() ?: continue

                when (categoriaMostrar) {
                    1 -> menu.mostrarMenu("Entradas")
                    2 -> menu.mostrarMenu("Platos Fuertes")
                    3 -> menu.mostrarMenu("Postres")
                    4 -> menu.mostrarMenu("Bebidas")
                    else -> println("Opción inválida")
                }
            }
            3 -> {
                print("Ingrese la categoría del plato a modificar: ")
                val categoria = readLine() ?: ""
                print("Ingrese el índice del plato a modificar: ")
                val indice = readLine()?.toIntOrNull() ?: -1

                when (categoria) {
                    "Entradas", "Platos Fuertes", "Postres", "Bebidas" -> {
                        val cantidadPlatos = menu.cantidadPlatos(categoria)
                        if (indice in 0 until cantidadPlatos) {
                            print("Ingrese el nuevo nombre del plato: ")
                            val nombre = readLine() ?: ""
                            print("Ingrese la nueva descripción del plato: ")
                            val descripcion = readLine() ?: ""
                            print("Ingrese el nuevo precio del plato: ")
                            val precio = readLine()?.toDoubleOrNull() ?: 0.0

                            val platoModificado = Plato(nombre, descripcion, precio)

                            menu.modificarPlato(categoria, indice, platoModificado)
                            println("Plato modificado con éxito")
                        } else {
                            println("Índice inválido")
                        }
                    }
                    else -> println("Categoría inválida")
                }
            }
            4 -> {
                print("Ingrese la categoría del plato a eliminar: ")
                val categoria = readLine() ?: ""
                print("Ingrese el índice del plato a eliminar: ")
                val indice = readLine()?.toIntOrNull() ?: -1

                when (categoria) {
                    "Entradas", "Platos Fuertes", "Postres", "Bebidas" -> {
                        val cantidadPlatos = menu.cantidadPlatos(categoria)
                        if (indice in 0 until cantidadPlatos) {
                            menu.eliminarPlato(categoria, indice)
                            println("Plato eliminado con éxito")
                        } else {
                            println("Índice inválido")
                        }
                    }
                    else -> println("Categoría inválida")
                }
            }
            5 -> {
                println("Saliendo del programa...")
                return
            }
            else -> println("Opción inválida")
        }
    }
}
