package com.juliluli19.fundamentos.Reto2

class Reto2{

}
class Cancion(val titulo: String, val artista: String, val añoPublicacion: Int, var reproducciones: Int) {
    fun descripcion(): String {
        return "$titulo, interpretada por $artista, se lanzó en $añoPublicacion, $reproducciones reproducciones."
    }
}

class Album(val tipoMusica: String) {
    private val canciones = mutableListOf<Cancion>()

    fun agregarCancion(cancion: Cancion) {
        canciones.add(cancion)
    }

    fun cantidadCanciones(): Int {
        return canciones.size
    }

    fun cancionMasPopular(): Cancion? {
        return canciones.maxByOrNull { it.reproducciones }
    }

    fun evaluarPopularidad() {
        println("Evaluación de popularidad del álbum:")
        for (cancion in canciones) {
            val popularidad = if (cancion.reproducciones >= 1000) "popular" else "poco popular"
            println("${cancion.titulo} es $popularidad")
        }
    }

    fun imprimirDescripciones() {
        println("Descripciones de las canciones del álbum:")
        for (cancion in canciones) {
            println(cancion.descripcion())
        }
    }
}

fun main() {
    val album = Album("Pop")

    val cancion1 = Cancion("Canción 1", "Artista 1", 2020, 1500)
    val cancion2 = Cancion("Canción 2", "Artista 2", 2019, 800)
    val cancion3 = Cancion("Canción 3", "Artista 3", 2022, 3000)

    album.agregarCancion(cancion1)
    album.agregarCancion(cancion2)
    album.agregarCancion(cancion3)

    println("El álbum tiene ${album.cantidadCanciones()} canciones.")
    println("Tipo de música: ${album.tipoMusica}")

    val cancionPopular = album.cancionMasPopular()
    if (cancionPopular != null) {
        println("La canción más popular del álbum es: ${cancionPopular.titulo}")
    }

    album.evaluarPopularidad()
    album.imprimirDescripciones()
}
