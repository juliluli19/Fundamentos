package com.juliluli19.fundamentos.Reto1

import android.content.pm.LauncherApps.PinItemRequest

class Reto1 {

}
fun main(){
    var res=1
    var cont=0
    val notis = mutableListOf<String>()
    while (res==1){
    println("1.Agregar una nueva notificacion\n2.Ver Notificaciones")
    var noti= readln().toInt()
    var bu:String= "si"
    while (noti==1){
        println("Escriba la notificacion que desea agregar")
        var notifi = readLine()!!.toString()
        println("Add notifi: ${notis.add("$notifi")}")
        cont+=1
        println("Desea Agregar Una Nueva Notificaiòn?\n->1 Para Agregar una nueva Notificacion \n->2 Para Ver Notificaciones")
        noti= readLine()!!.toInt()
    }
    if(cont<100){
        println("Usyted tiene $cont Notificaciones")
        println("Desea leer las notificaciones?Digite si o no?")
        var rep = readLine()!!.toString()
        if (rep=="si"){
            println("$notis")
                res=0
            }else{
                res=0
            }
        }else if (cont>100){
            println("Usyted tiene +99 Notificaciones")
            println("Desea leer las notificaciones?Digite si o no?")
        var rep = readLine()!!.toString()
            if (rep=="si"){
                println(notis)
                res=0
            }else{
                res=0
            }
        }else{
            println("No existen mensajes disponibles")
            res=0
        }
    }
}
